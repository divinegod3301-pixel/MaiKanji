# TYRO KANJI

Offline Japanese Kanji learning app and resizable Glance home-screen widget.

## Build
Use Java 17 and Gradle 8.11.1, then run `gradle :app:assembleDebug`.

## Product
Home dashboard, searchable Kanji library, Kanji detail cards, flashcards, quiz mode, SRS review buttons, favorites, statistics, settings, offline Room persistence, and a responsive light/dark widget with a top-right refresh action.

## Data
The supplied Kanji source contains 307 records. No fabricated records are included. JLPT metadata is nullable because the supplied source does not contain authoritative per-record JLPT classifications.

## Dictionary data attribution

Kanji On'yomi/Kun'yomi readings are based on KANJIDIC2 data maintained by the Electronic Dictionary Research and Development Group (EDRDG). Common example words/compounds are based on JMdict Japanese-English dictionary data maintained by EDRDG. Data is included with attribution and under the applicable Creative Commons Attribution-ShareAlike terms.

## Latest UI update
- Kanji Details reveal panel now shows On'yomi, Kun'yomi, and the two most-used double-kanji examples already carried by all 307 catalog records.
- Quiz choices are transparent until answered; correct is a full-opacity green stroke with 25% green fill, and a selected wrong choice is a full-opacity red stroke with 25% red fill.
- Widget has a top-right manual refresh button, transparent background, device-aware default color, 10 color choices, working size controls, horizontal appearance controls, and auto-refresh choices from Off through 1 day.
- Learning Content includes a separate My Imported Kanji section and an Import New Kanji action.

## MaiKanji update
- App label: MaiKanji.
- Quiz choices are transparent until answered; the tapped correct choice uses a 100% green stroke with 25% green fill, and a tapped wrong choice uses a 100% red stroke with 25% red fill.
- Widget has a top-right manual refresh button and selectable auto-refresh intervals: Off, 5m, 10m, 30m, 1h, 2h, 12h, 1d.
- Widget appearance controls are horizontally scrollable, with 10 color choices, device/light/dark behavior, fonts, and Kanji size +/-.
- Learning Content includes Import New Kanji, stored separately with IDs >= 10000 and selectable for study/widget use.
