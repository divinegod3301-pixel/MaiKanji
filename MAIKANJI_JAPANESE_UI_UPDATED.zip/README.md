# MaiKanji

Japanese-inspired Kanji learning app.

## UI update
- Calm Japanese sunset atmosphere across the app.
- Dark/light theme adaptation.
- Subtle mountains, torii, sunset glow and gently falling cherry blossoms.
- MaiKanji branding and Japanese-inspired typography.
- Existing Flash Cards behavior preserved.

## Quiz
- Transparent choices by default.
- Correct selected choice: 100% green stroke + 25% green fill, then automatic advance.
- Wrong selected choice: 100% red stroke + 25% red fill and stays on the question until Next is tapped.

## Widget
- Top-right manual refresh.
- Immediate manual refresh/settings updates.
- Font and Kanji size controls.
- Ten colors including Device.
- Auto refresh: Off, 5m, 10m, 30m, 1h, 2h, 12h, 1d.

## Imported Kanji
- Settings > Learning content > Import New Kanji.
- Supports `保 protect`, `保 — protect`, and `保 — ほ — protect`.
- The second field of a two-field import is always treated as the English meaning.
- Imported entries have individual Delete controls and never delete the original 307 Kanji.
