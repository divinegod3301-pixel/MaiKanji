package com.tyro.kanji

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.tyro.kanji.data.KanjiEntity
import com.tyro.kanji.data.ProgressEntity

private val LocalMaiDark = compositionLocalOf { false }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TyroKanjiApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TyroKanjiApp(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    var tab by remember { mutableStateOf(0) }
    val theme by vm.theme.collectAsState()
    val systemDark = isSystemInDarkTheme()
    val dark = when (theme) { "dark" -> true; "light" -> false; else -> systemDark }

    val light = lightColorScheme(
        primary = Color(0xFFE85D72), secondary = Color(0xFF8B5A83), tertiary = Color(0xFFF2A65A),
        background = Color(0xFFFFF7F4), surface = Color(0xFFFFF7F4), surfaceVariant = Color(0xFFF5E8E8)
    )
    val darkScheme = darkColorScheme(
        primary = Color(0xFFFF7186), secondary = Color(0xFFE7A4C3), tertiary = Color(0xFFFFB86B),
        background = Color(0xFF130F1D), surface = Color(0xFF191422), surfaceVariant = Color(0xFF292031)
    )
    CompositionLocalProvider(LocalMaiDark provides dark) {
        MaterialTheme(colorScheme = if (dark) darkScheme else light) {
            Scaffold(containerColor = Color.Transparent, bottomBar = {
            NavigationBar(containerColor = if (dark) Color(0xDD17121F) else Color(0xEEFDF1F3)) {
                listOf("Home", "Learn", "Study", "Stats", "Settings").forEachIndexed { i, label ->
                    val icon = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.School, Icons.Default.Insights, Icons.Default.Settings)[i]
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i; nav.navigate(label.lowercase()) { launchSingleTop = true } },
                        icon = { Icon(icon, null) }, label = { Text(label) }
                    )
                }
            }
        }) { pad ->
            NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
                composable("home") { Home(vm) }
                composable("learn") { Learn(vm) { nav.navigate("detail/$it") } }
                composable("study") { Study(vm) }
                composable("stats") { Stats(vm) }
                composable("settings") { Settings(nav) }
                composable("settings/learning") { LearningContent(vm, nav) }
                composable("settings/flashcards") { FlashcardSettings(vm, nav) }
                composable("settings/quiz") { QuizSettings(nav) }
                composable("settings/widget") { WidgetAppearance(vm, nav) }
                composable("settings/theme") { ThemeSettings(vm, nav) }
                composable("settings/jlpt") { JlptSettings(nav) }
                composable("settings/notifications") { SimpleSettingsPage("Notifications", "Notification controls can be enabled here. The current build keeps notifications off by default.", nav) }
                composable("settings/backup") { SimpleSettingsPage("Backup", "Your learning data is stored locally on the device. Backup/export can be added here without changing your study data.", nav) }
                composable("settings/faq") { SimpleSettingsPage("FAQ", "Choose your Kanji in Learning content. Shuffle them in Flashcards. Use ↻ in Study and on the widget to switch instantly.", nav) }
                composable("detail/{id}") { e ->
                    val id = e.arguments?.getString("id")?.toIntOrNull()
                    val k = vm.kanji.collectAsState().value.firstOrNull { it.id == id }
                    if (k != null) Detail(k, vm) { nav.popBackStack() }
                }
            }
        }
        }
    }
}

@Composable
fun JapaneseBackdrop(content: @Composable BoxScope.() -> Unit) {
    val dark = LocalMaiDark.current
    val petals = remember { List(20) { Triple(Random(it + 17).nextFloat(), Random(it + 71).nextFloat(), Random(it + 101).nextFloat()) } }
    val transition = rememberInfiniteTransition(label = "petals")
    val drift by transition.animateFloat(0f, 1f, animationSpec = infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Restart), label = "drift")
    Canvas(Modifier.fillMaxSize()) {
        val top = if (dark) Color(0xFF171225) else Color(0xFFFFE8E2)
        val bottom = if (dark) Color(0xFF090A14) else Color(0xFFFFF9F5)
        drawRect(Brush.verticalGradient(listOf(top, bottom)))
        val horizon = size.height * 0.38f
        // soft sunset glow
        drawCircle(Color(0xFFFF9A73).copy(alpha = if (dark) .26f else .18f), size.minDimension * .15f, Offset(size.width * .78f, horizon))
        // distant mountain silhouette
        val mountain = Path().apply {
            moveTo(0f, horizon + 90f)
            lineTo(size.width * .22f, horizon - 20f)
            lineTo(size.width * .38f, horizon + 70f)
            lineTo(size.width * .54f, horizon - 60f)
            lineTo(size.width * .72f, horizon + 60f)
            lineTo(size.width, horizon - 5f)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(mountain, Color(0xFF5C4965).copy(alpha = if (dark) .58f else .20f))
        // Mount Fuji-inspired peak
        val fuji = Path().apply {
            moveTo(size.width * .48f, horizon + 80f)
            lineTo(size.width * .63f, horizon - 105f)
            lineTo(size.width * .78f, horizon + 80f)
            close()
        }
        drawPath(fuji, Color(0xFF453A55).copy(alpha = if (dark) .75f else .22f))
        // torii at the lower horizon
        val tx = size.width * .16f; val ty = size.height * .72f
        drawRect(Color(0xFFE85D72).copy(alpha=.72f), Offset(tx,ty), Size(size.width*.18f, 10f))
        drawRect(Color(0xFFE85D72).copy(alpha=.62f), Offset(tx+size.width*.03f,ty+10f), Size(12f, size.height*.12f))
        drawRect(Color(0xFFE85D72).copy(alpha=.62f), Offset(tx+size.width*.15f,ty+10f), Size(12f, size.height*.12f))
        // falling blossoms
        petals.forEachIndexed { i, (x, y, phase) ->
            val yy = ((y + drift * (.35f + phase*.65f)) % 1f) * size.height
            val xx = (x * size.width + sin((drift + phase) * 6.28f) * 26f + size.width) % size.width
            rotate(degrees = (phase + drift) * 360f, pivot = Offset(xx, yy)) {
                drawOval(Color(0xFFFF9FB1).copy(alpha = if (dark) .78f else .62f), Offset(xx, yy), Size(14f, 8f))
            }
        }
    }
    content()
}

@Composable fun Page(title: String, content: @Composable ColumnScope.() -> Unit) {
    JapaneseBackdrop {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp), content = content)
    }
}

@Composable fun Home(vm: MainViewModel) {
    val list by vm.kanji.collectAsState(); val mastered by vm.mastered.collectAsState(); val due by vm.due.collectAsState()
    Page("Home") {
        Spacer(Modifier.height(24.dp))
        Text("MaiKanji", fontFamily = FontFamily.Cursive, fontSize = 38.sp, fontWeight = FontWeight.Bold)
        Text("学ぶ • 覚える • 極める", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))
        Card(shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .86f)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Today's Goal", style = MaterialTheme.typography.labelLarge)
                        Text("${minOf(list.size, 20)} / 20", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    }
                    Text("🌸", fontSize = 28.sp)
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(progress = { if (list.isEmpty()) 0f else (mastered.toFloat()/list.size).coerceIn(0f,1f) }, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary)
                Text("$mastered mastered  •  $due reviews due", Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("307 Kanji", list.size.toString(), Modifier.weight(1f))
            StatCard("Mastered", mastered.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Smart Quiz", "Test", Modifier.weight(1f)); StatCard("Flash Cards", "Review", Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Text("日本の夕暮れ", fontFamily = FontFamily.Cursive, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("A calm Japanese sunset atmosphere for focused learning.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable fun StatCard(a: String, b: String, m: Modifier) { Card(m, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .80f))) { Column(Modifier.padding(15.dp)) { Text(b, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text(a, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }

@Composable fun Learn(vm: MainViewModel, onOpen: (Int) -> Unit) {
    val list by vm.filtered.collectAsState(); val q by vm.query.collectAsState()
    Page("Learn") {
        Spacer(Modifier.height(18.dp)); OutlinedTextField(q, vm::setQuery, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search Kanji, meaning, reading…") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        Spacer(Modifier.height(12.dp)); Text("${list.size} Kanji", fontWeight = FontWeight.SemiBold)
        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { items(list, key = { it.id }) { k -> KanjiRow(k) { onOpen(k.id) } } }
    }
}

@Composable fun KanjiRow(k: KanjiEntity, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(k.kanji, modifier = Modifier.width(70.dp), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
            Column { Text(k.hiragana, fontWeight = FontWeight.SemiBold); Text(k.romaji, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(k.meaning, maxLines = 1) }
        }
    }
}

@Composable fun Detail(k: KanjiEntity, vm: MainViewModel, back: () -> Unit) {
    var flipped by remember { mutableStateOf(false) }
    val p by vm.progress(k.id).collectAsState(initial = ProgressEntity(k.id))
    val words = k.example.split("|").filter { it.isNotBlank() }.take(2)
    val readings = k.exampleRomaji.split("|")
    val meanings = k.exampleMeaning.split("|")

    Page("Kanji details") {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(back) { Icon(Icons.Default.ArrowBack, null) }
            Text("Kanji details", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Card(
            Modifier.fillMaxWidth().clickable { flipped = !flipped },
            shape = RoundedCornerShape(30.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    Modifier.weight(0.42f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(k.kanji, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
                    Text(k.hiragana, style = MaterialTheme.typography.titleLarge)
                    Text(k.romaji, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.width(12.dp))
                Column(
                    Modifier.weight(0.58f),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    if (!flipped) {
                        Text("Tap to reveal", style = MaterialTheme.typography.titleMedium)
                        Text("On'yomi + Kun'yomi + 2 common uses", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text(k.meaning, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("On'yomi", fontWeight = FontWeight.SemiBold)
                        Text(k.onyomi.ifBlank { "—" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Kun'yomi", fontWeight = FontWeight.SemiBold)
                        Text(k.kunyomi.ifBlank { "—" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Most used", fontWeight = FontWeight.SemiBold)
                        words.forEachIndexed { i, word ->
                            val reading = readings.getOrNull(i).orEmpty()
                            Text(word + if (reading.isNotBlank()) "  •  $reading" else "", fontWeight = FontWeight.SemiBold)
                            meanings.getOrNull(i)?.takeIf { it.isNotBlank() }?.let {
                                Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(k.meaning, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Tap the right side of the card to reveal the readings and two common uses.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Most used double-kanji words", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (words.isEmpty()) Text("No common-use entries available.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                words.forEachIndexed { i, word ->
                    val reading = readings.getOrNull(i).orEmpty()
                    val meaning = meanings.getOrNull(i).orEmpty()
                    Text(word + if (reading.isNotBlank()) "  •  $reading" else "", fontWeight = FontWeight.SemiBold)
                    if (meaning.isNotBlank()) Text(meaning, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(8.dp)); Text("Mastery ${p.mastery}/5")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(p.favorite, { vm.favorite(k.id, !p.favorite) }, label = { Text(if (p.favorite) "Saved" else "Favorite") }, leadingIcon = { Icon(Icons.Default.Favorite, null) })
        }
        Spacer(Modifier.height(18.dp)); Text("SRS review", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Again" to 0, "Hard" to 1, "Good" to 2, "Easy" to 3).forEach { (t, r) -> Button({ vm.review(k.id, r) }, Modifier.weight(1f)) { Text(t) } }
        }
    }
}

@Composable fun Study(vm: MainViewModel) {
    val all by vm.kanji.collectAsState(); val selectedIds by vm.selectedIds.collectAsState(); val shuffle by vm.shuffle.collectAsState(); val token by vm.refreshToken.collectAsState()
    val list = remember(all, selectedIds, shuffle, token) { vm.studyOrder(all) }
    var index by remember { mutableIntStateOf(0) }; var mode by remember { mutableIntStateOf(0) }; var reveal by remember { mutableStateOf(false) }
    val quizScope = rememberCoroutineScope()
    LaunchedEffect(list.size) { if (list.isEmpty()) index = 0 else index %= list.size }
    val k = list.getOrNull(index)
    Page("Study") {
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(mode == 0, { mode = 0 }, label = { Text("Flashcards") }); Spacer(Modifier.width(8.dp)); FilterChip(mode == 1, { mode = 1 }, label = { Text("Quiz") })
            Spacer(Modifier.weight(1f)); IconButton(onClick = { vm.refreshStudy(); index = 0; reveal = false }) { Icon(Icons.Default.Refresh, contentDescription = "New Kanji") }
        }
        Spacer(Modifier.height(8.dp)); Text("${list.size} selected${if (shuffle) " • shuffled" else ""}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))
        if (k == null) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(24.dp)) { Text("No Kanji selected", style = MaterialTheme.typography.titleLarge); Text("Open Settings → Learning content and choose the Kanji you want to learn.") } }
        } else if (mode == 0) {
            Card(Modifier.fillMaxWidth().height(390.dp).clickable { reveal = !reveal }, shape = RoundedCornerShape(32.dp)) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(k.kanji, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
                    if (reveal) { Text(k.meaning, style = MaterialTheme.typography.headlineSmall); Text(k.hiragana); Text(k.romaji, color = MaterialTheme.colorScheme.onSurfaceVariant) } else Text("Tap to flip", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else QuizCard(k, all) { answer ->
            vm.review(k.id, if (answer) 2 else 0)
            if (answer) {
                // Correct: show the green state briefly, then auto-advance.
                quizScope.launch { delay(360); index = if (list.isEmpty()) 0 else (index + 1) % list.size; reveal = false }
            }
        }
        Spacer(Modifier.height(14.dp))
        if (list.isNotEmpty()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton({ index = (index - 1 + list.size) % list.size; reveal = false }, Modifier.weight(1f)) { Text("Previous") }
            Button({ index = (index + 1) % list.size; reveal = false }, Modifier.weight(1f)) { Text("Next") }
        }
    }
}

@Composable fun QuizCard(k: KanjiEntity, all: List<KanjiEntity>, onAnswer: (Boolean) -> Unit) {
    var answered by remember(k.id) { mutableStateOf(false) }
    var selectedId by remember(k.id) { mutableIntStateOf(-1) }
    val opts = remember(k.id, all) { (listOf(k) + all.filter { it.id != k.id }.shuffled().take(3)).shuffled() }
    Card(Modifier.fillMaxWidth().padding(top = 4.dp), shape = RoundedCornerShape(28.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("What does this mean?", style = MaterialTheme.typography.titleMedium)
            Text(k.kanji, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                opts.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { o ->
                            val isSelected = selectedId == o.id
                            val isCorrect = o.id == k.id
                            // Answer boxes are transparent until the user taps one.
                            // Only the tapped option receives the result state: green for
                            // a correct answer or red for a wrong answer. Stroke is fully
                            // opaque; the fill is intentionally faded to 25%.
                            val border = when {
                                answered && isSelected && isCorrect -> Color(0xFF2E7D32)
                                answered && isSelected && !isCorrect -> Color(0xFFC62828)
                                else -> Color.Transparent
                            }
                            val fill = when {
                                answered && isSelected && isCorrect -> Color(0xFF4CAF50).copy(alpha = 0.25f)
                                answered && isSelected && !isCorrect -> Color(0xFFF44336).copy(alpha = 0.25f)
                                else -> Color.Transparent
                            }
                            OutlinedButton(
                                enabled = !answered,
                                onClick = { selectedId = o.id; answered = true; onAnswer(isCorrect) },
                                modifier = Modifier.weight(1f).heightIn(min = 54.dp),
                                shape = RoundedCornerShape(14.dp),
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, border),
                                colors = ButtonDefaults.outlinedButtonColors(containerColor = fill, disabledContainerColor = fill, disabledContentColor = MaterialTheme.colorScheme.onSurface)
                            ) { Text(o.meaning, maxLines = 2) }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun Stats(vm: MainViewModel) { val total by vm.kanji.collectAsState(); val mastered by vm.mastered.collectAsState(); Page("Statistics") { Spacer(Modifier.height(18.dp)); Text("Your progress", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(16.dp)); StatCard("Learned / mastered", "$mastered / ${total.size}", Modifier.fillMaxWidth()); Spacer(Modifier.height(12.dp)); Text("Accuracy and review history are stored offline in Room and updated by SRS reviews.", color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@Composable fun Settings(nav: NavHostController) {
    Page("Settings") {
        Spacer(Modifier.height(18.dp)); Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp))
        val rows = listOf(
            "Learning content" to "settings/learning", "JLPT level" to "settings/jlpt", "Flashcards" to "settings/flashcards", "Quiz" to "settings/quiz",
            "Widget appearance" to "settings/widget", "Theme" to "settings/theme", "Statistics" to "stats", "Notifications" to "settings/notifications", "Backup" to "settings/backup", "FAQ" to "settings/faq"
        )
        rows.forEach { (label, route) -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { nav.navigate(route) }, shape = RoundedCornerShape(18.dp)) { ListItem(headlineContent = { Text(label) }, trailingContent = { Icon(Icons.Default.ChevronRight, null) }) } }
    }
}

@Composable fun SettingsHeader(title: String, nav: NavHostController) { Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Back") }; Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }

@Composable fun LearningContent(vm: MainViewModel, nav: NavHostController) {
    val all by vm.kanji.collectAsState()
    val selected by vm.selectedIds.collectAsState()
    var search by remember { mutableStateOf("") }
    var showImport by remember { mutableStateOf(false) }
    var importText by remember { mutableStateOf("") }
    val visible = all.filter { search.isBlank() || it.kanji.contains(search) || it.hiragana.contains(search) || it.meaning.contains(search, true) }
    val original = visible.filter { it.id < 10000 }
    val imported = visible.filter { it.id >= 10000 }
    Page("Learning content") {
        SettingsHeader("Learning content", nav)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("${selected.size} / ${all.size} selected", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f)); TextButton({ vm.selectAll() }) { Text("All") }; TextButton({ vm.clearSelection() }) { Text("None") }
        }
        OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search Kanji") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        Spacer(Modifier.height(8.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            if (imported.isNotEmpty()) {
                item { Text("My Imported Kanji", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 10.dp)) }
                items(imported, key = { it.id }) { k ->
                    Row(Modifier.fillMaxWidth().clickable { vm.setSelected(k.id, k.id !in selected) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = k.id in selected, onCheckedChange = { vm.setSelected(k.id, it) })
                        Text(k.kanji, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.width(58.dp))
                        Column(Modifier.weight(1f)) { if (k.hiragana != "—") Text(k.hiragana); Text(k.meaning, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        IconButton(onClick = { vm.deleteImportedKanji(k.id) }) { Icon(Icons.Default.DeleteOutline, contentDescription = "Delete imported Kanji") }
                    }
                }
                item { HorizontalDivider(Modifier.padding(vertical = 8.dp)) }
            }
            item { Text("Original 307 Kanji", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 10.dp)) }
            items(original, key = { it.id }) { k ->
                Row(Modifier.fillMaxWidth().clickable { vm.setSelected(k.id, k.id !in selected) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = k.id in selected, onCheckedChange = { vm.setSelected(k.id, it) })
                    Text(k.kanji, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.width(58.dp))
                    Column { Text(k.hiragana); Text(k.meaning, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
            item {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { importText = ""; showImport = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Import New Kanji")
                }
            }
        }
    }
    if (showImport) {
        AlertDialog(
            onDismissRequest = { showImport = false },
            title = { Text("Import New Kanji") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Use one Kanji per line, or: 海 — うみ — sea. You can also paste several Kanji together.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(importText, { importText = it }, modifier = Modifier.fillMaxWidth().height(180.dp), placeholder = { Text("海\n山\n川\n\n海 — うみ — sea") })
                }
            },
            confirmButton = {
                Button(onClick = { vm.importKanji(importText); showImport = false }) { Text("Import") }
            },
            dismissButton = { TextButton(onClick = { showImport = false }) { Text("Cancel") } }
        )
    }
}

@Composable fun FlashcardSettings(vm: MainViewModel, nav: NavHostController) {
    val shuffle by vm.shuffle.collectAsState()
    Page("Flashcards") { SettingsHeader("Flashcards", nav); Spacer(Modifier.height(16.dp)); SettingSwitch("Shuffle Kanji", "Show the selected Kanji in a different order each time you refresh Study.", shuffle, vm::setShuffle); Spacer(Modifier.height(14.dp)); Text("Use the ↻ button in Study to instantly start with a new Kanji.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
}

@Composable fun QuizSettings(nav: NavHostController) { Page("Quiz") { SettingsHeader("Quiz", nav); Spacer(Modifier.height(16.dp)); Text("Answer layout", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text("4 choices in a compact 2 × 2 layout. Wrong answers are taken only from the 307-Kanji catalog.", color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@Composable fun WidgetAppearance(vm: MainViewModel, nav: NavHostController) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("tyro_settings", 0) }
    var font by remember { mutableStateOf(prefs.getString("widget_font", "sans") ?: "sans") }
    var size by remember { mutableIntStateOf(prefs.getInt("widget_size", 48)) }
    var color by remember { mutableStateOf(prefs.getString("widget_color", "auto") ?: "auto") }
    var autoRefresh by remember { mutableIntStateOf(prefs.getInt("widget_auto_refresh", 5)) }
    val fonts = listOf("sans" to "Sans", "serif" to "Serif", "mono" to "Mono", "cursive" to "Cursive")
    val colors = listOf(
        "auto" to "Device", "white" to "White", "black" to "Black", "blue" to "Blue", "green" to "Green",
        "purple" to "Purple", "orange" to "Orange", "pink" to "Pink", "red" to "Red", "cyan" to "Cyan"
    )
    val refreshes = listOf(0 to "Off", 5 to "5m", 10 to "10m", 30 to "30m", 60 to "1h", 120 to "2h", 720 to "12h", 1440 to "1d")
    Page("Widget appearance") {
        SettingsHeader("Widget appearance", nav)
        Spacer(Modifier.height(8.dp))
        Text("Transparent widget. Device mode = white text in dark mode and dark text in light mode.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Text("Font", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            fonts.forEach { (key, label) ->
                FilterChip(selected = font == key, onClick = { font = key; vm.saveWidgetFont(key) }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Kanji size", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconButton(onClick = { val next = (size - 4).coerceAtLeast(28); size = next; vm.saveWidgetSize(next) }) { Icon(Icons.Default.Remove, "Smaller") }
            Text("$size sp", style = MaterialTheme.typography.titleMedium, modifier = Modifier.width(58.dp))
            IconButton(onClick = { val next = (size + 4).coerceAtMost(72); size = next; vm.saveWidgetSize(next) }) { Icon(Icons.Default.Add, "Larger") }
        }
        Spacer(Modifier.height(8.dp))
        Text("Color", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            colors.forEach { (key, label) -> FilterChip(selected = color == key, onClick = { color = key; vm.saveWidgetColor(key) }, label = { Text(label) }) }
        }
        Spacer(Modifier.height(10.dp))
        Text("Auto refresh", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            refreshes.forEach { (minutes, label) ->
                FilterChip(selected = autoRefresh == minutes, onClick = { autoRefresh = minutes; vm.saveWidgetAutoRefresh(minutes) }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("The top-right ↻ on the widget always works for an instant new Kanji. Automatic intervals are system-scheduled and may be delayed by Android battery optimization.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable fun ThemeSettings(vm: MainViewModel, nav: NavHostController) {
    val theme by vm.theme.collectAsState()
    Page("Theme") { SettingsHeader("Theme", nav); Spacer(Modifier.height(16.dp)); listOf("system" to "Device default", "light" to "Light", "dark" to "Dark").forEach { (key, label) -> Row(Modifier.fillMaxWidth().clickable { vm.setTheme(key) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(theme == key, { vm.setTheme(key) }); Text(label) } } }
}

@Composable fun JlptSettings(nav: NavHostController) { Page("JLPT level") { SettingsHeader("JLPT level", nav); Spacer(Modifier.height(16.dp)); Text("The current 307-Kanji catalog is not tagged with JLPT levels, so all 307 Kanji remain available. No Kanji are silently removed.", color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@Composable fun SimpleSettingsPage(title: String, body: String, nav: NavHostController) { Page(title) { SettingsHeader(title, nav); Spacer(Modifier.height(18.dp)); Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@Composable fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleMedium); Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Switch(checked, onChange) } }
