package com.tyro.kanji.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="kanji")
data class KanjiEntity(
    @PrimaryKey(autoGenerate=true) val id:Int=0,
    val kanji:String,
    val hiragana:String,
    val romaji:String,
    val meaning:String,
    val jlpt:String? = null,
    val strokeCount:Int? = null,
    val onyomi:String = "",
    val kunyomi:String = "",
    val example:String = "",
    val exampleRomaji:String = "",
    val exampleMeaning:String = ""
)

@Entity(tableName="progress", primaryKeys=["kanjiId"])
data class ProgressEntity(
    val kanjiId:Int,
    val favorite:Boolean=false,
    val intervalDays:Int=0,
    val ease:Double=2.5,
    val dueAt:Long=0L,
    val repetitions:Int=0,
    val correct:Int=0,
    val wrong:Int=0,
    val mastery:Int=0,
    val lastReviewed:Long=0L
)

@Dao
interface KanjiDao {
    @Query("SELECT * FROM kanji ORDER BY id")
    fun observeAll(): Flow<List<KanjiEntity>>
    @Query("SELECT * FROM kanji WHERE kanji LIKE '%' || :q || '%' OR hiragana LIKE '%' || :q || '%' OR romaji LIKE '%' || :q || '%' OR meaning LIKE '%' || :q || '%' ORDER BY id")
    fun search(q:String): Flow<List<KanjiEntity>>
    @Query("SELECT * FROM kanji WHERE id=:id LIMIT 1")
    suspend fun get(id:Int): KanjiEntity?
    @Query("SELECT COUNT(*) FROM kanji")
    suspend fun count():Int
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertAll(items:List<KanjiEntity>)
    @Query("SELECT * FROM progress WHERE kanjiId=:id LIMIT 1")
    suspend fun progress(id:Int): ProgressEntity?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun saveProgress(p:ProgressEntity)
    @Query("SELECT * FROM progress WHERE favorite=1 ORDER BY kanjiId")
    fun favorites(): Flow<List<ProgressEntity>>
    @Query("SELECT COUNT(*) FROM progress WHERE mastery >= 4")
    fun mastered(): Flow<Int>
    @Query("SELECT COUNT(*) FROM progress WHERE dueAt <= :now AND repetitions > 0")
    fun dueCount(now:Long): Flow<Int>
}

@Database(entities=[KanjiEntity::class,ProgressEntity::class], version=1, exportSchema=false)
abstract class TyroDatabase:RoomDatabase() {
    abstract fun kanjiDao():KanjiDao
    companion object {
        @Volatile private var INSTANCE:TyroDatabase?=null
        fun get(context:Context):TyroDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext,TyroDatabase::class.java,"tyro_kanji.db").build().also { INSTANCE=it }
        }
    }
}

object DatabaseSeeder {
    suspend fun seed(db:TyroDatabase) {
        val items = KanjiCatalog.items.mapIndexed { index, s ->
            KanjiEntity(
                id=index+1,
                kanji=s.kanji,
                hiragana=s.reading,
                romaji=romanize(s.reading),
                meaning=s.meaning,
                onyomi=s.onyomi,
                kunyomi=s.kunyomi,
                example=listOf(s.example1, s.example2).filter { it.isNotBlank() }.joinToString("|"),
                exampleRomaji=listOf(s.example1Reading, s.example2Reading).filter { it.isNotBlank() }.joinToString("|"),
                exampleMeaning=listOf(s.example1Meaning, s.example2Meaning).filter { it.isNotBlank() }.joinToString("|"),
            )
        }
        db.kanjiDao().insertAll(items)
    }
    private fun romanize(s:String):String {
        val map = mapOf(
            "あ" to "a","い" to "i","う" to "u","え" to "e","お" to "o",
            "か" to "ka","き" to "ki","く" to "ku","け" to "ke","こ" to "ko",
            "さ" to "sa","し" to "shi","す" to "su","せ" to "se","そ" to "so",
            "た" to "ta","ち" to "chi","つ" to "tsu","て" to "te","と" to "to",
            "な" to "na","に" to "ni","ぬ" to "nu","ね" to "ne","の" to "no",
            "は" to "ha","ひ" to "hi","ふ" to "fu","へ" to "he","ほ" to "ho",
            "ま" to "ma","み" to "mi","む" to "mu","め" to "me","も" to "mo",
            "や" to "ya","ゆ" to "yu","よ" to "yo","ら" to "ra","り" to "ri","る" to "ru","れ" to "re","ろ" to "ro",
            "わ" to "wa","を" to "o","ん" to "n",
            "が" to "ga","ぎ" to "gi","ぐ" to "gu","げ" to "ge","ご" to "go",
            "ざ" to "za","じ" to "ji","ず" to "zu","ぜ" to "ze","ぞ" to "zo",
            "だ" to "da","ぢ" to "ji","づ" to "zu","で" to "de","ど" to "do",
            "ば" to "ba","び" to "bi","ぶ" to "bu","べ" to "be","ぼ" to "bo",
            "ぱ" to "pa","ぴ" to "pi","ぷ" to "pu","ぺ" to "pe","ぽ" to "po",
            "きゃ" to "kya","きゅ" to "kyu","きょ" to "kyo","しゃ" to "sha","しゅ" to "shu","しょ" to "sho",
            "ちゃ" to "cha","ちゅ" to "chu","ちょ" to "cho","にゃ" to "nya","にゅ" to "nyu","にょ" to "nyo",
            "ひゃ" to "hya","ひゅ" to "hyu","ひょ" to "hyo","みゃ" to "mya","みゅ" to "myu","みょ" to "myo",
            "りゃ" to "rya","りゅ" to "ryu","りょ" to "ryo","じゃ" to "ja","じゅ" to "ju","じょ" to "jo",
            "っ" to ""
        )
        var out=s
        map.keys.sortedByDescending{it.length}.forEach { k -> out=out.replace(k,map[k]!!) }
        return out
    }
}
